from visualize_tensor.cli import main
main()
