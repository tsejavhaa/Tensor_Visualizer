"""
visualize_tensor.cli  —  command-line interface
Usage:
    python -m visualize_tensor --help
    python -m visualize_tensor demo
    python -m visualize_tensor file my_tensor.pt
    python -m visualize_tensor file my_array.npy
"""

import argparse
import sys


# ─── helpers ──────────────────────────────────────────────────────────────────

def _load_file(path: str):
    """Load a tensor/array from a .pt, .pth, .npy, or .npz file."""
    import numpy as np

    if path.endswith((".pt", ".pth")):
        try:
            import torch
        except ImportError:
            print("❌  PyTorch is not installed. Install it with:  pip install torch")
            sys.exit(1)
        obj = torch.load(path, map_location="cpu", weights_only=True)
        # unwrap common containers
        if isinstance(obj, dict):
            keys = list(obj.keys())
            if len(keys) == 1:
                obj = obj[keys[0]]
            else:
                print(f"ℹ️  File contains a dict with keys: {keys}")
                key = input("   Which key to visualize? ").strip()
                obj = obj[key]
        return obj

    elif path.endswith(".npy"):
        return np.load(path, allow_pickle=False)

    elif path.endswith(".npz"):
        data = np.load(path, allow_pickle=False)
        keys = list(data.keys())
        if len(keys) == 1:
            return data[keys[0]]
        print(f"ℹ️  .npz contains arrays: {keys}")
        key = input("   Which array to visualize? ").strip()
        return data[key]

    else:
        print(f"❌  Unsupported file type: {path}")
        print("   Supported: .pt  .pth  .npy  .npz")
        sys.exit(1)


def _print_summary(arr):
    import numpy as np
    flat = arr.ravel()
    print()
    print("─" * 44)
    print(f"  shape   : {arr.shape}")
    print(f"  dtype   : {arr.dtype}")
    print(f"  ndim    : {arr.ndim}")
    print(f"  numel   : {flat.size:,}")
    print(f"  min     : {flat.min():.6f}")
    print(f"  max     : {flat.max():.6f}")
    print(f"  mean    : {float(flat.mean()):.6f}")
    print(f"  std     : {float(flat.std()):.6f}")
    print("─" * 44)
    print()


# ─── sub-commands ─────────────────────────────────────────────────────────────

def cmd_demo(args):
    """Run a quick demo with a random 10×10×3 tensor."""
    import numpy as np
    from visualize_tensor import show_layers, show_heatmap, show_stats, tensor_summary

    try:
        import torch
        t = torch.rand(10, 10, 3)
        print(f"✅  torch.rand(10, 10, 3)")
    except ImportError:
        rng = np.random.default_rng(42)
        t   = rng.random((10, 10, 3))
        print(f"ℹ️  PyTorch not found — using numpy array of shape (10, 10, 3)")

    tensor_summary(t)

    mode = args.mode or "layers"
    if mode == "layers":
        show_layers(t, title="Demo — 10×10×3 random tensor")
    elif mode == "heatmap":
        show_heatmap(t, title="Demo — per-channel heatmap")
    elif mode == "stats":
        show_stats(t, title="Demo — stats panel")
    else:
        show_layers(t, title="Demo — 10×10×3 random tensor")


def cmd_file(args):
    """Visualize a tensor saved on disk."""
    import numpy as np
    from visualize_tensor import show

    path = args.path
    print(f"📂  Loading: {path}")
    obj  = _load_file(path)

    # convert torch → numpy if needed
    if hasattr(obj, "detach"):
        arr = obj.detach().cpu().numpy()
    else:
        arr = np.asarray(obj)

    _print_summary(arr)

    mode = args.mode or "auto"
    if mode == "auto":
        show(arr, title=path)
    elif mode == "layers":
        from visualize_tensor import show_layers
        show_layers(arr, title=path)
    elif mode == "heatmap":
        from visualize_tensor import show_heatmap
        show_heatmap(arr, title=path)
    elif mode == "stats":
        from visualize_tensor import show_stats
        show_stats(arr, title=path)


def cmd_info(args):
    """Print version and available functions."""
    import visualize_tensor as vt
    print(f"\n  visualize-tensor  {vt.__version__}")
    print("  ─────────────────────────────")
    print("  show(t)            auto-selects best view")
    print("  show_layers(t)     stacked offset grid layers")
    print("  show_heatmap(t)    per-channel colour heatmap")
    print("  show_stats(t)      histogram + stats table")
    print("  tensor_summary(t)  console stats print")
    print()


# ─── main ─────────────────────────────────────────────────────────────────────

def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="python -m visualize_tensor",
        description="🧊  visualize-tensor — friendly tensor visualizer",
    )
    sub = parser.add_subparsers(dest="cmd")

    # demo
    p_demo = sub.add_parser("demo", help="Run a demo with a random 10×10×3 tensor")
    p_demo.add_argument("--mode", choices=["layers", "heatmap", "stats"],
                        default="layers", help="Visualization mode")

    # file
    p_file = sub.add_parser("file", help="Visualize a .pt / .npy / .npz file")
    p_file.add_argument("path", help="Path to the tensor file")
    p_file.add_argument("--mode", choices=["auto", "layers", "heatmap", "stats"],
                        default="auto", help="Visualization mode (default: auto)")

    # info
    sub.add_parser("info", help="Print version and available functions")

    args = parser.parse_args(argv)

    if args.cmd == "demo":
        cmd_demo(args)
    elif args.cmd == "file":
        cmd_file(args)
    elif args.cmd == "info":
        cmd_info(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
