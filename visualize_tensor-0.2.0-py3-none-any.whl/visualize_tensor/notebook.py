"""
visualize_tensor.notebook  —  Jupyter / IPython integration helpers.

Adds rich repr methods to torch.Tensor so that just *evaluating* a tensor
in a Jupyter cell renders the stacked-layer visualization automatically.

Usage (in a Jupyter notebook cell):
    import visualize_tensor.notebook  # run once; no return value needed
    t = torch.rand(10, 10, 3)
    t  # ← evaluating t now shows the visualization inline
"""

from __future__ import annotations
import io
import base64


def _tensor_to_png_b64(tensor) -> str:
    """Render a tensor via matplotlib and return a base64-encoded PNG."""
    import matplotlib
    matplotlib.use("Agg")          # non-interactive backend
    import matplotlib.pyplot as plt
    from visualize_tensor.core import show_layers, show_heatmap, _to_numpy, _show_1d

    arr = _to_numpy(tensor)

    fig = plt.figure()

    if arr.ndim == 1:
        plt.close(fig)
        _show_1d(arr, title=f"Tensor {arr.shape}", decimals=2,
                 figsize=(max(6, len(arr) * 0.6 + 1), 2),
                 cmap="coolwarm", show_values=True, cell_size=0.6)
        buf = io.BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight", dpi=110)
        plt.close()
        buf.seek(0)
        return base64.b64encode(buf.read()).decode()

    plt.close(fig)

    if arr.ndim == 2:
        show_heatmap(arr, title=f"Tensor {arr.shape}", show_values=True)
    elif arr.ndim == 3:
        show_layers(arr, title=f"Tensor {arr.shape}")
    else:
        # 4-D+: show first 2-D slice
        show_heatmap(arr.reshape(-1, arr.shape[-1])[:20, :20],
                     title=f"Tensor {arr.shape}  (first slice)")

    buf = io.BytesIO()
    plt.savefig(buf, format="png", bbox_inches="tight", dpi=110)
    plt.close()
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()


def _repr_png_(self):
    try:
        b64 = _tensor_to_png_b64(self)
        import struct, zlib
        # return raw bytes that Jupyter renders as image/png
        return base64.b64decode(b64)
    except Exception:
        return None


def _repr_html_(self):
    try:
        b64 = _tensor_to_png_b64(self)
        shape = tuple(self.shape) if hasattr(self, "shape") else "?"
        return (
            f'<div style="font-family:monospace;font-size:11px;color:#666;margin-bottom:4px">'
            f'Tensor {shape}</div>'
            f'<img src="data:image/png;base64,{b64}" style="max-width:100%"/>'
        )
    except Exception:
        return None


def patch_torch():
    """Monkey-patch torch.Tensor with rich Jupyter repr methods."""
    try:
        import torch
        torch.Tensor._repr_png_  = _repr_png_
        torch.Tensor._repr_html_ = _repr_html_
        print("✅  visualize-tensor: torch.Tensor now has rich Jupyter repr.")
        print("   Evaluate any tensor in a cell to visualize it automatically.")
    except ImportError:
        print("⚠️  PyTorch not found — Jupyter patch skipped.")


# Auto-apply when the module is imported
patch_torch()
